function login() {
  document.getElementById('premium-section').classList.remove('hidden');
  document.getElementById('ai-section').classList.remove('hidden');
  alert('Login berhasil (dummy)!');
}

function register() {
  alert('Registrasi berhasil (dummy)!');
}

function logout() {
  alert('Logout berhasil (dummy)!');
  document.getElementById('premium-section').classList.add('hidden');
  document.getElementById('ai-section').classList.add('hidden');
}

function subscribePremium() {
  alert('Transaksi dummy: Premium aktif 2 bulan!');
}

function askAI() {
  let q = document.getElementById('question').value;
  document.getElementById('answer').innerText = 'Jawaban AI (dummy) untuk: ' + q;
}
